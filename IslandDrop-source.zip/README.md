# VORAXIS

Dynamic Island giả cho Android, làm cho Oppo A53: viên thuốc đen che lỗ camera góc trên bên trái,
rớt xuống khi có sự kiện, bấm vào để mở bảng có nút.

## Cách hoạt động
1. **Rớt xuống (INFO)**: có sự kiện thì đảo rớt từ camera xuống thành thanh dọc hẹp (hình, tiêu đề, nội dung ngắn).
   Tắt "Đảo dọc" trong Cài đặt thì nó rớt thành thẻ ngang như trước.
2. **Bấm vào đảo (PANEL)**: thanh dọc bung rộng thành bảng đầy đủ nội dung, có hàng nút chức năng (mở, bỏ qua, điều khiển nhạc, nghe/từ chối...).
3. **Tự thu lại**: về viên nhỏ cạnh camera nếu đang phát nhạc/video hoặc bật đèn pin/đang gọi, còn lại thì ẩn.

## Sự kiện hỗ trợ
- Thông báo: icon app, tiêu đề, toàn bộ nội dung; nút Mở / nút của thông báo / Bỏ qua.
- Nhạc và video: đang phát thì đảo luôn hiện cạnh camera, bấm vào ra nút điều khiển; dừng phát thì ẩn.
- Chặn cứng banner hệ thống (Cài đặt, mặc định tắt): mọi thông báo xóa được bị xóa khỏi hệ thống ngay khi đến,
  chỉ còn hiện trên đảo. Không còn lưu trong thanh thông báo. Cần bật Truy cập thông báo.
- Sạc: hình điện thoại được cắm dây sạc, % pin, nguồn sạc, nhiệt độ.
- Cuộc gọi đến: đảo tự mở rộng, nút Từ chối / Trả lời; khi đang gọi hiện đồng hồ, nút Kết thúc.
- Tai nghe có dây và Bluetooth: hiện tên thiết bị khi kết nối.
- Đèn pin: viên nhỏ luôn hiện khi đang bật, bấm để mở nút Tắt.
- Giờ: hiện cạnh camera, bấm để xem giờ lớn và ngày.

## Build
- **Android Studio**: mở thư mục, đợi Gradle sync, bấm Run.
- **GitHub Actions**: workflow của repo giải nén `IslandDrop-source.zip` rồi build ra APK.

## Cài đặt trên máy
1. Mở app, cấp từng quyền cho đến khi dòng nào cũng có dấu ✓ xanh.
2. Bấm **Bật đảo**.
3. Vào **Cài đặt → Căn vị trí camera**, kéo 3 thanh trượt cho viên thuốc che vừa khít lỗ camera.
   Giá trị mặc định (26 / 20 / 22 dp) chỉ là ước lượng cho Oppo A53.
4. Dùng mục **Thử hiệu ứng** trên màn hình chính để xem từng kiểu.

## Lưu ý cho Oppo / ColorOS
- Cài đặt → Pin → cho VORAXIS **chạy nền không hạn chế** và bật **Tự khởi động**.
- Một số bản ColorOS không cho overlay vẽ lên thanh trạng thái; nếu viên thuốc bị lệch,
  chỉnh "Cách mép trên".
- Nghe/cúp cuộc gọi từ đảo cần quyền Điện thoại; tên người gọi lấy từ thông báo cuộc gọi
  nên cần bật Truy cập thông báo.
