# IslandDrop — Dynamic Island for OPPO A53

Android app project designed for OPPO A53 CPH2127 / Android 12. Build using GitHub Actions without a computer.

## Build on GitHub from your phone
1. Create a new GitHub repository named `IslandDrop` (public or private).
2. Upload the **contents** of this project, including the hidden `.github` folder. Use GitHub's web upload flow or the GitHub mobile/web interface.
3. Open the repository → **Actions** → **Build IslandDrop APK** → **Run workflow**.
4. Wait for the run to finish green. Open that run, scroll to **Artifacts**, and download `IslandDrop-debug-apk`.
5. Extract the ZIP on your phone and install `app-debug.apk`. Android may ask you to allow installs from the browser/file manager you used.

## First launch
1. Open IslandDrop.
2. Grant “Display over other apps”.
3. Grant Notification Access if you want notification titles to be detected.
4. Tap “Run Dynamic Island”.
5. Tap the pill to expand/collapse; tap “Try drop animation” to preview the bounce effect.

## Current implementation status (honest)
- Implemented: floating pill overlay, tap-to-expand, drag repositioning, battery percentage, charging state, clock, demo drop/bounce animation, notification-listener service that can receive notification titles.
- Known integration work remaining: notification listener events are not yet connected to the overlay receiver; music session controls and a functional timer/settings UI are not yet implemented in this starter build. Android overlay placement is approximate and may need adjustment for ColorOS. Do not treat this starter as feature-complete.
- This is an unsigned debug APK, suitable for personal testing. Do not install builds from unknown sources.
