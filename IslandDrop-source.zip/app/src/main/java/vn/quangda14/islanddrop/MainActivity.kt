package vn.quangda14.islanddrop

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(0xFF101116.toInt())
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(0xFFF5F5F7.toInt())
            setPadding(0, dp(8), 0, dp(8))
        }
        fun button(text: String, action: () -> Unit) = Button(this).apply {
            this.text = text; isAllCaps = false
            setOnClickListener { action() }
            root.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(8) })
        }
        root.addView(label("ISLAND DROP", 28f))
        root.addView(label("Dynamic Island • OPPO A53 / Android 12"))
        root.addView(label("Bật quyền cần thiết bên dưới. Sau đó khởi chạy viên thuốc nổi.", 14f))
        button("1 · Cấp quyền hiển thị trên ứng dụng khác") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("2 · Cấp quyền đọc thông báo") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        button("3 · Chạy Dynamic Island") {
            if (!Settings.canDrawOverlays(this)) {
                AlertDialog.Builder(this).setMessage("Hãy cấp quyền hiển thị trên ứng dụng khác trước.").setPositiveButton("OK", null).show()
            } else {
                startService(Intent(this, IslandService::class.java))
            }
        }
        button("Dừng Dynamic Island") { stopService(Intent(this, IslandService::class.java)) }
        button("Thử hiệu ứng rơi") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, IslandService::class.java).putExtra("demo", true))
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        root.addView(label("Lưu ý: Android/ColorOS có thể yêu cầu bật tự khởi chạy hoặc bỏ tối ưu pin để dịch vụ ổn định.", 12f))
        setContentView(root)
    }
}
