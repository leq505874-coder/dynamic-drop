package vn.quangda14.islanddrop

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.BounceInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var pill: LinearLayout
    private lateinit var title: TextView
    private lateinit var detail: TextView
    private lateinit var params: WindowManager.LayoutParams
    private var expanded = false
    private var batteryPct = -1
    private var charging = false
    private var notice = "Sẵn sàng • chạm để mở rộng"
    private var timerEnd = 0L
    private var timerRunnable: Runnable? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        pill = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.BLACK); cornerRadius = dp(28).toFloat()
                setStroke(dp(1), 0xFF34343A.toInt())
            }
            elevation = dp(12).toFloat()
        }
        title = TextView(this).apply {
            text = "●  IslandDrop"; setTextColor(0xFF70F0A0.toInt())
            textSize = 13f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }
        detail = TextView(this).apply {
            text = "Chạm để mở rộng"; setTextColor(Color.WHITE)
            textSize = 12f; gravity = Gravity.CENTER; visibility = View.GONE
        }
        pill.addView(title)
        pill.addView(detail)
        params = WindowManager.LayoutParams(dp(142), dp(42),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            // A53 has a waterdrop notch; position just below the status-bar/camera area.
            y = dp(8)
        }
        pill.setOnClickListener { expanded = !expanded; updatePill(true) }
        pill.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
            private var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=params.x; startY=params.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        if (kotlin.math.abs(e.rawX-downX)>dp(6) || kotlin.math.abs(e.rawY-downY)>dp(6)) moved=true
                        if (moved) { params.x=startX+(e.rawX-downX).toInt(); params.y=startY+(e.rawY-downY).toInt(); wm.updateViewLayout(pill,params) }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) { expanded=!expanded; updatePill(true) }
                        return true
                    }
                }
                return true
            }
        })
        wm.addView(pill, params)
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        registerReceiver(batteryReceiver, filter)
        registerReceiver(noticeReceiver, IntentFilter("vn.quangda14.islanddrop.NOTICE"))
        updatePill(false)
    }
    private val noticeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            notice = intent?.getStringExtra("text") ?: "Thông báo mới"
            expanded = true
            updatePill(true)
        }
    }
    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            batteryPct = (level * 100) / scale
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            updatePill(false)
        }
    }
    private fun animateDrop() {
        pill.post {
            val original = params.y
            params.y = -dp(30)
            wm.updateViewLayout(pill, params)
            pill.animate().translationY(dp(0).toFloat()).setDuration(620).setInterpolator(BounceInterpolator()).withEndAction {
                params.y = original
                wm.updateViewLayout(pill, params)
                pill.translationY = 0f
                expanded = true
                updatePill(false)
            }.start()
        }
    }
    private fun updatePill(animate: Boolean) {
        if (!::pill.isInitialized) return
        title.text = when {
            charging -> "⚡  Đang sạc • $batteryPct%"
            batteryPct >= 0 -> "●  IslandDrop • $batteryPct%"
            else -> "●  IslandDrop"
        }
        detail.text = buildString {
            append(notice)
            if (batteryPct >= 0) append("\nPin $batteryPct% ${if (charging) "• Đang sạc" else ""}")
            if (timerEnd > 0) {
                val remain = ((timerEnd - System.currentTimeMillis()).coerceAtLeast(0) / 1000)
                append("\nHẹn giờ: %02d:%02d".format(remain / 60, remain % 60))
            }
            append("\n").append(DateFormat.getTimeInstance(DateFormat.SHORT).format(Date()))
        }
        detail.visibility = if (expanded) View.VISIBLE else View.GONE
        params.width = dp(if (expanded) 270 else 142)
        params.height = dp(if (expanded) 104 else 42)
        try { wm.updateViewLayout(pill, params) } catch (_: Exception) {}
        if (animate) {
            pill.scaleX = 0.85f; pill.scaleY = 0.85f
            pill.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(BounceInterpolator()).start()
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getBooleanExtra("demo", false) == true) animateDrop()
        val seconds = intent?.getIntExtra("timer_seconds", 0) ?: 0
        if (seconds > 0) {
            timerEnd = System.currentTimeMillis() + seconds * 1000L
            notice = "Hẹn giờ đã bắt đầu"
            expanded = true
            updatePill(true)
            pill.removeCallbacks(timerRunnable)
            timerRunnable = object : Runnable {
                override fun run() {
                    if (timerEnd <= System.currentTimeMillis()) {
                        notice = "⏱ Hết giờ!"
                        timerEnd = 0L
                        updatePill(true)
                    } else {
                        updatePill(false)
                        pill.postDelayed(this, 1000)
                    }
                }
            }
            pill.post(timerRunnable!!)
        }
        return START_STICKY
    }
    fun showNotification(text: String) { notice = text.take(100); updatePill(true) }
    override fun onDestroy() {
        timerRunnable?.let { pill.removeCallbacks(it) }
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(noticeReceiver) } catch (_: Exception) {}
        if (::pill.isInitialized) try { wm.removeView(pill) } catch (_: Exception) {}
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
