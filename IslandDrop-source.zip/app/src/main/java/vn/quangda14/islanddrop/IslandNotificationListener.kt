package vn.quangda14.islanddrop

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class IslandNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val app = sbn.packageName.substringAfterLast('.')
        val text = extras.getCharSequence("android.title")?.toString()
            ?: extras.getCharSequence("android.text")?.toString()
            ?: "Thông báo mới"
        // Keep notification access local; broadcast only a short display string to the overlay.
        sendBroadcast(android.content.Intent("vn.quangda14.islanddrop.NOTICE").apply {
            setPackage(packageName)
            putExtra("text", "$app: $text".take(100))
        })
    }
}
