package com.dynamicdrop

import android.app.PendingIntent
import android.graphics.drawable.Drawable
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Kind { NOTIF, MUSIC, BATTERY, CALL, HEADSET, TORCH, CLOCK }

/** COMPACT: viên thuốc nhỏ cạnh camera. INFO: rớt xuống hiện thông tin. PANEL: bấm vào để hiện nút. */
enum class Level { COMPACT, INFO, PANEL }

enum class Style { NEUTRAL, PRIMARY, DANGER, SUCCESS, ICON, ICON_PRIMARY }

class IslandAction(
    val label: String,
    val style: Style = Style.NEUTRAL,
    val iconRes: Int = 0,
    /** true: bấm xong thu đảo lại. */
    val closes: Boolean = true,
    val act: () -> Unit
)

data class IslandContent(
    val kind: Kind,
    val label: String,
    val title: String,
    val text: String = "",
    val extra: String = "",
    val icon: Drawable? = null,
    val emoji: String = "",
    val compactText: String = "",
    val percent: Int = 0,
    val actions: List<IslandAction> = emptyList(),
    val intent: PendingIntent? = null
)

/** Cầu nối giữa NotifListener / Activity và IslandService. */
object IslandBus {
    @Volatile
    var service: IslandService? = null

    /** Dịch vụ Trợ năng đang bật (nếu có): cho phép vẽ đảo đè lên thanh trạng thái và bấm được. */
    @Volatile
    var a11y: VoraxisAccessibility? = null

    fun post(c: IslandContent, level: Level = Level.INFO) {
        service?.post(c, level)
    }
}

fun nowTime(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

fun fmtDur(ms: Long): String {
    val s = ms / 1000
    return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
}
