package com.dynamicdrop

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {

    override fun onListenerConnected() {
        // Quyền vừa được cấp: cho service đảo bắt đầu theo dõi nhạc.
        IslandBus.service?.startMedia()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()

        // Thông báo cuộc gọi: chỉ lấy tên người gọi cho đảo cuộc gọi, không hiện như thông báo thường.
        if (n.category == Notification.CATEGORY_CALL) {
            IslandBus.service?.onCallNotification(title)
            return
        }

        if ((n.flags and (Notification.FLAG_GROUP_SUMMARY or Notification.FLAG_ONGOING_EVENT)) != 0) return
        if (n.category == Notification.CATEGORY_TRANSPORT || n.category == Notification.CATEGORY_PROGRESS) return

        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val pm = packageManager
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) {
            sbn.packageName
        }
        val icon = try {
            pm.getApplicationIcon(sbn.packageName)
        } catch (_: Exception) {
            null
        }

        val actions = ArrayList<IslandAction>()
        n.contentIntent?.let { pi ->
            actions += IslandAction("Mở", Style.PRIMARY) { pi.send() }
        }
        n.actions
            ?.filter { it.remoteInputs.isNullOrEmpty() && it.actionIntent != null && !it.title.isNullOrBlank() }
            ?.take(2)
            ?.forEach { a ->
                actions += IslandAction(a.title.toString().take(14), Style.NEUTRAL) { a.actionIntent.send() }
            }
        actions += IslandAction("Bỏ qua", Style.NEUTRAL) {}

        IslandBus.post(
            IslandContent(
                Kind.NOTIF, label, title.ifBlank { label }, text,
                icon = icon, actions = actions
            ),
            Level.INFO
        )
    }
}
