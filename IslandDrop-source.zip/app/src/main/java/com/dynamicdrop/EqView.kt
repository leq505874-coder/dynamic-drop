package com.dynamicdrop

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/** Ba thanh nhạc nhảy lên xuống, dùng trong cục nhạc ở đáy màn hình. */
class EqView(ctx: Context) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val level = floatArrayOf(0.5f, 0.9f, 0.65f)
    private val rect = RectF()

    private val anims = listOf(520L, 380L, 450L).mapIndexed { i, dur ->
        ValueAnimator.ofFloat(0.25f, 1f).apply {
            duration = dur
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                level[i] = it.animatedValue as Float
                invalidate()
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anims.forEach { it.start() }
    }

    override fun onDetachedFromWindow() {
        anims.forEach { it.cancel() }
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val bw = w / 5f
        for (i in 0 until 3) {
            val left = i * bw * 2f
            val bh = (level[i] * h).coerceAtLeast(bw)
            rect.set(left, h - bh, left + bw, h)
            canvas.drawRoundRect(rect, bw / 2f, bw / 2f, paint)
        }
    }
}
