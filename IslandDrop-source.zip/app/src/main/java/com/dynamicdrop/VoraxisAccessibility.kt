package com.dynamicdrop

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Dịch vụ Trợ năng chỉ dùng để có cửa sổ TYPE_ACCESSIBILITY_OVERLAY: loại cửa sổ này nằm TRÊN thanh trạng thái
 * và nhận được cú chạm, còn overlay thường (TYPE_APPLICATION_OVERLAY) bị thanh trạng thái che mất và không bấm được.
 * Dịch vụ không đọc nội dung màn hình.
 */
class VoraxisAccessibility : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        IslandBus.a11y = this
        IslandBus.service?.refresh()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        if (IslandBus.a11y === this) IslandBus.a11y = null
        IslandBus.service?.refresh()
        return super.onUnbind(intent)
    }
}
