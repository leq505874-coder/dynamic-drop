package com.dynamicdrop

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Bộ dựng giao diện tối, bo góc, hiện đại cho các màn hình của app. */
object Ui {
    val BG = Color.parseColor("#0F0F14")
    val CARD = Color.parseColor("#1A1A22")
    val CHIP = Color.parseColor("#2C2C34")
    val SUB = Color.parseColor("#9A9AA5")
    val ACCENT = Color.parseColor("#0A84FF")
    val GREEN = Color.parseColor("#30D158")
    val RED = Color.parseColor("#FF453A")
    val AMBER = Color.parseColor("#FF9F0A")

    private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun shape(color: Int, radiusPx: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx
    }

    fun ripple(color: Int, radiusPx: Float): Drawable =
        RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), shape(color, radiusPx), null)

    fun lp(w: Int = MATCH, h: Int = WRAP, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply {
            topMargin = top
            bottomMargin = bottom
        }

    fun text(c: Context, s: String, sp: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(c).apply {
            text = s
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun roundClip(v: View, radiusPx: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
            }
        }
        v.clipToOutline = true
    }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        val p = dp(c, 16)
        setPadding(p, p, p, p)
        background = shape(CARD, dp(c, 22).toFloat())
    }

    fun sectionTitle(c: Context, s: String) = text(c, s.uppercase(), 12f, SUB, true).apply {
        letterSpacing = 0.08f
        setPadding(dp(c, 6), 0, 0, dp(c, 8))
    }

    /** Nút bo tròn dạng viên thuốc. */
    fun button(
        c: Context,
        label: String,
        color: Int,
        heightDp: Int = 50,
        sp: Float = 15f,
        onClick: () -> Unit
    ) = TextView(c).apply {
        text = label
        textSize = sp
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.WHITE)
        background = ripple(color, dp(c, heightDp / 2).toFloat())
        minimumHeight = dp(c, heightDp)
        setPadding(dp(c, 18), 0, dp(c, 18), 0)
        setOnClickListener { onClick() }
    }

    /** Một dòng quyền: dấu ✓ xanh khi đã cấp, dấu ! cam + nút "Cấp" khi chưa. */
    fun permRow(c: Context, title: String, desc: String, granted: Boolean, onClick: () -> Unit): View {
        val row = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(c, 8), 0, dp(c, 8))
        }
        val badge = TextView(c).apply {
            text = if (granted) "✓" else "!"
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            background = shape(if (granted) GREEN else AMBER, dp(c, 15).toFloat())
        }
        row.addView(badge, LinearLayout.LayoutParams(dp(c, 30), dp(c, 30)).apply { marginEnd = dp(c, 14) })

        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text(c, title, 15f, Color.WHITE, true))
        col.addView(text(c, desc, 12f, SUB))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))

        if (!granted) {
            val b = button(c, "Cấp", ACCENT, 36, 13f, onClick)
            row.addView(b, LinearLayout.LayoutParams(WRAP, dp(c, 36)).apply { marginStart = dp(c, 8) })
        }
        return row
    }

    fun switchRow(c: Context, title: String, desc: String, key: String, onChange: () -> Unit): View {
        val row = LinearLayout(c).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(c, 8), 0, dp(c, 8))
        }
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text(c, title, 15f, Color.WHITE, true))
        if (desc.isNotBlank()) col.addView(text(c, desc, 12f, SUB))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))

        val sw = Switch(c).apply {
            isChecked = Config.on(c, key)
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.parseColor("#C7C7CC")))
            trackTintList = ColorStateList(states, intArrayOf(GREEN, Color.parseColor("#3A3A3C")))
            setOnCheckedChangeListener { _, on ->
                Config.setOn(c, key, on)
                onChange()
            }
        }
        row.addView(sw)
        return row
    }

    fun slider(
        c: Context,
        name: String,
        key: String,
        lo: Int,
        hi: Int,
        def: Float,
        unit: String,
        onStop: () -> Unit
    ): View {
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(c, 6), 0, dp(c, 6))
        }
        val label = text(c, "", 14f)
        val tint = ColorStateList.valueOf(ACCENT)
        val bar = SeekBar(c).apply {
            max = hi - lo
            progress = (Config.get(c, key, def) - lo).toInt().coerceIn(0, hi - lo)
            progressTintList = tint
            thumbTintList = tint
        }
        fun upd() {
            label.text = "$name: ${bar.progress + lo} $unit"
        }
        upd()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                upd()
                Config.set(c, key, (p + lo).toFloat())
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                onStop()
            }
        })
        box.addView(label)
        box.addView(bar)
        return box
    }
}

/** Kiểm tra từng quyền để hiện dấu tích. */
object Perms {
    fun overlay(c: Context) = android.provider.Settings.canDrawOverlays(c)

    fun accessibility(c: Context): Boolean {
        val s = android.provider.Settings.Secure.getString(
            c.contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        return s?.contains(c.packageName + "/") == true
    }

    fun listener(c: Context): Boolean {
        val s = android.provider.Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners")
        return s?.contains(c.packageName) == true
    }

    private fun has(c: Context, p: String) =
        c.checkSelfPermission(p) == android.content.pm.PackageManager.PERMISSION_GRANTED

    val phonePerms = arrayOf(
        android.Manifest.permission.READ_PHONE_STATE,
        android.Manifest.permission.ANSWER_PHONE_CALLS
    )

    fun phone(c: Context) = phonePerms.all { has(c, it) }

    fun bluetooth(c: Context) =
        android.os.Build.VERSION.SDK_INT < 31 || has(c, "android.permission.BLUETOOTH_CONNECT")

    fun post(c: Context) =
        android.os.Build.VERSION.SDK_INT < 33 || has(c, android.Manifest.permission.POST_NOTIFICATIONS)
}
