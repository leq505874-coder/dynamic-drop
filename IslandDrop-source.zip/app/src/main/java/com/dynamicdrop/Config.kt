package com.dynamicdrop

import android.content.Context

/** Cài đặt của app. Vị trí camera tính bằng dp. */
object Config {
    const val CX = "cx"
    const val CY = "cy"
    const val SIZE = "size"
    const val INFO_SEC = "info_sec"

    const val F_NOTIF = "f_notif"
    const val F_MUSIC = "f_music"
    const val F_CHARGE = "f_charge"
    const val F_CALL = "f_call"
    const val F_HEADSET = "f_headset"
    const val F_TORCH = "f_torch"
    const val F_CLOCK = "f_clock"
    const val F_BLOCK = "f_block"

    private fun p(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun get(c: Context, key: String, def: Float) = p(c).getFloat(key, def)
    fun set(c: Context, key: String, v: Float) = p(c).edit().putFloat(key, v).apply()

    /** Mặc định bật hết, riêng đồng hồ cạnh camera và chặn banner hệ thống thì tắt. */
    fun on(c: Context, key: String) = p(c).getBoolean(key, key != F_CLOCK && key != F_BLOCK)
    fun setOn(c: Context, key: String, v: Boolean) = p(c).edit().putBoolean(key, v).apply()

    fun cx(c: Context) = get(c, CX, 26f)
    fun cy(c: Context) = get(c, CY, 20f)
    fun size(c: Context) = get(c, SIZE, 22f)
    fun infoMs(c: Context) = (get(c, INFO_SEC, 5f) * 1000).toLong()

    fun enabled(c: Context) = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()
}
