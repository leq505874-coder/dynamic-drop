package com.dynamicdrop

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import android.view.animation.OvershootInterpolator

/** Chiếc điện thoại được cắm dây sạc: dây trồi lên cắm vào, tia sét nhấp nháy. */
class ChargeView(ctx: Context) : View(ctx) {

    var percent = 50

    private val d = ctx.resources.displayMetrics.density
    private var plug = 0f
    private var pulse = 1f

    private val green = Color.parseColor("#30D158")
    private val red = Color.parseColor("#FF453A")

    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 2f * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val cable = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#8E8E93")
        strokeWidth = 2.5f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val plugPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D1D1D6") }
    private val bolt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    private val rect = RectF()
    private val plugRect = RectF()
    private val path = Path()

    private val plugAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 900
        interpolator = OvershootInterpolator()
        addUpdateListener {
            plug = it.animatedValue as Float
            invalidate()
        }
    }
    private val pulseAnim = ValueAnimator.ofFloat(0.45f, 1f).apply {
        duration = 700
        repeatMode = ValueAnimator.REVERSE
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener {
            pulse = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        plugAnim.start()
        pulseAnim.start()
    }

    override fun onDetachedFromWindow() {
        plugAnim.cancel()
        pulseAnim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val l = w * 0.18f
        val r = w * 0.82f
        val t = h * 0.02f
        val b = h * 0.76f
        val rad = w * 0.15f
        val cx = (l + r) / 2f

        // mức pin: tô từ đáy lên, cắt theo góc bo của máy
        rect.set(l, t, r, b)
        canvas.save()
        path.reset()
        path.addRoundRect(rect, rad, rad, Path.Direction.CW)
        canvas.clipPath(path)
        fill.color = if (percent <= 20) red else green
        fill.alpha = 150
        val top = b - (b - t) * percent.coerceIn(0, 100) / 100f
        canvas.drawRect(l, top, r, b, fill)
        canvas.restore()
        canvas.drawRoundRect(rect, rad, rad, outline)

        // tia sét
        val s = (r - l) * 0.5f
        val cy = (t + b) / 2f
        path.reset()
        path.moveTo(cx + 0.15f * s, cy - 0.95f * s)
        path.lineTo(cx - 0.55f * s, cy + 0.1f * s)
        path.lineTo(cx - 0.05f * s, cy + 0.1f * s)
        path.lineTo(cx - 0.15f * s, cy + 0.95f * s)
        path.lineTo(cx + 0.55f * s, cy - 0.1f * s)
        path.lineTo(cx + 0.05f * s, cy - 0.1f * s)
        path.close()
        bolt.alpha = (pulse * 255).toInt()
        canvas.drawPath(path, bolt)

        // đầu sạc trồi lên từ dưới rồi cắm vào đáy máy, dây kéo xuống
        val dock = b + 1.5f * d
        val y = dock + (1f - plug) * h * 0.3f
        val connH = h * 0.1f
        plugRect.set(cx - w * 0.11f, y, cx + w * 0.11f, y + connH)
        canvas.drawLine(cx, y + connH, cx, h + 4f * d, cable)
        canvas.drawRoundRect(plugRect, 2f * d, 2f * d, plugPaint)
    }
}
