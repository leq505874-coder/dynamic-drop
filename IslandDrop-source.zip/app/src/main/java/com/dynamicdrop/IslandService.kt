package com.dynamicdrop

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager
import android.view.WindowManager
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Bộ não của đảo: nhận sự kiện (thông báo, nhạc, sạc, cuộc gọi, tai nghe, đèn pin, giờ)
 * và quyết định đảo đang ở mức nào (COMPACT / INFO / PANEL).
 */
class IslandService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var view: IslandView? = null
    private var current: IslandContent? = null
    private var level = Level.COMPACT

    /** Hoạt động đang chạy nền, luôn hiện viên nhỏ cạnh camera (đèn pin, cuộc gọi). */
    private var live: IslandContent? = null

    /** Cuộc gọi đang đổ chuông: đảo tự mở rộng và giữ nguyên đến khi hết đổ chuông. */
    private var ringing: IslandContent? = null

    private var callerName: String? = null
    private var callStart = 0L
    private var callsStarted = false

    private var torchOn = false
    private var torchId: String? = null

    private val settleTask = Runnable { settle() }
    private val tickTask = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 1000)
        }
    }

    // ---------------------------------------------------------------- vòng đời

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        IslandBus.service = this
        startForeground(1, buildNotification())

        registerReceiver(receiver, IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_BATTERY_LOW)
            addAction(AudioManager.ACTION_HEADSET_PLUG)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        })
        try {
            val cm = getSystemService(CameraManager::class.java)
            cm.registerTorchCallback(torchCallback, handler)
        } catch (_: Exception) {
        }
        startMedia()
        startCalls()
        handler.post { settle() }
        handler.postDelayed(tickTask, 1000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        IslandBus.service = null
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(receiver)
        } catch (_: Exception) {
        }
        try {
            getSystemService(CameraManager::class.java).unregisterTorchCallback(torchCallback)
        } catch (_: Exception) {
        }
        try {
            @Suppress("DEPRECATION")
            getSystemService(TelephonyManager::class.java)
                .listen(phoneListener, PhoneStateListener.LISTEN_NONE)
        } catch (_: Exception) {
        }
        try {
            msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {
        }
        tracked.values.forEach { (c, cb) -> c.unregisterCallback(cb) }
        tracked.clear()
        view?.destroy()
        view = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- điều khiển hiển thị

    private fun allowed(k: Kind) = when (k) {
        Kind.NOTIF -> Config.on(this, Config.F_NOTIF)
        Kind.MUSIC -> Config.on(this, Config.F_MUSIC)
        Kind.BATTERY -> Config.on(this, Config.F_CHARGE)
        Kind.CALL -> Config.on(this, Config.F_CALL)
        Kind.HEADSET -> Config.on(this, Config.F_HEADSET)
        Kind.TORCH -> Config.on(this, Config.F_TORCH)
        Kind.CLOCK -> Config.on(this, Config.F_CLOCK)
    }

    private fun ensureView(): IslandView =
        view ?: IslandView(this, wm, { onTap() }, { a -> onAction(a) }).also { view = it }

    private fun display(c: IslandContent, lv: Level) {
        if (!Settings.canDrawOverlays(this)) return
        current = c
        level = lv
        ensureView().render(c, lv)
    }

    private fun schedule(lv: Level) {
        handler.removeCallbacks(settleTask)
        if (ringing != null) return
        when (lv) {
            Level.INFO -> handler.postDelayed(settleTask, Config.infoMs(this))
            Level.PANEL -> handler.postDelayed(settleTask, 9000)
            Level.COMPACT -> {}
        }
    }

    /** Hiện một sự kiện: đảo rớt xuống mức INFO (hoặc mức chỉ định). */
    fun post(c: IslandContent, lv: Level = Level.INFO) {
        handler.post {
            if (!allowed(c.kind)) return@post
            if (ringing != null && c.kind != Kind.CALL) return@post
            display(c, lv)
            schedule(lv)
        }
    }

    /** Thu đảo về trạng thái nền: viên đang chạy (đèn pin/cuộc gọi) > đồng hồ > ẩn. */
    private fun settle() {
        handler.removeCallbacks(settleTask)
        val r = ringing
        if (r != null) {
            display(r, Level.PANEL)
            return
        }
        val music = if (allowed(Kind.MUSIC)) playingController()?.let { musicContent(it) } else null
        val base = live ?: music ?: if (allowed(Kind.CLOCK)) clockContent() else null
        if (base != null && Settings.canDrawOverlays(this)) {
            display(base, Level.COMPACT)
        } else {
            current = null
            view?.hide()
            view = null
        }
    }

    /** Gọi khi đổi cài đặt / vị trí camera để dựng lại đảo. */
    fun refresh() {
        handler.post {
            handler.removeCallbacks(settleTask)
            view?.destroy()
            view = null
            current = null
            settle()
        }
    }

    private fun onTap() {
        val c = current ?: return
        if (ringing != null) return
        when (level) {
            Level.COMPACT -> {
                if (c.kind == Kind.CLOCK) {
                    display(clockContent(), Level.INFO)
                    schedule(Level.INFO)
                } else {
                    display(c, Level.PANEL)
                    schedule(Level.PANEL)
                }
            }
            Level.INFO -> {
                if (c.kind == Kind.CLOCK) {
                    settle()
                } else {
                    display(c, Level.PANEL)
                    schedule(Level.PANEL)
                }
            }
            Level.PANEL -> {
                display(c, Level.INFO)
                schedule(Level.INFO)
            }
        }
    }

    private fun onAction(a: IslandAction) {
        try {
            a.act()
        } catch (e: Exception) {
            Toast.makeText(this, "Không làm được: ${e.message}", Toast.LENGTH_SHORT).show()
        }
        if (a.closes) {
            settle()
        } else {
            schedule(level)
            if (current?.kind == Kind.MUSIC) handler.postDelayed({ refreshMusic() }, 300)
        }
    }

    private fun tick() {
        val c = current ?: return
        if (level != Level.COMPACT) return
        when (c.kind) {
            Kind.CLOCK -> view?.updateCompactText(nowTime())
            Kind.CALL -> view?.updateCompactText(fmtDur(System.currentTimeMillis() - callStart))
            else -> {}
        }
    }

    // ---------------------------------------------------------------- giờ

    private fun clockContent(): IslandContent {
        val t = nowTime()
        val date = SimpleDateFormat("EEEE, dd/MM/yyyy", Locale("vi", "VN")).format(Date())
        return IslandContent(
            Kind.CLOCK, "Đồng hồ", t,
            text = date, extra = "Pin ${batteryPercent()}%", compactText = t
        )
    }

    // ---------------------------------------------------------------- pin / sạc

    private fun batteryIntent() =
        applicationContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

    private fun batteryPercent(): Int {
        val b = batteryIntent() ?: return 0
        val level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (scale > 0) level * 100 / scale else 0
    }

    private fun chargingContent(pct: Int): IslandContent {
        val b = batteryIntent()
        val src = when (b?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Sạc cắm tường"
            BatteryManager.BATTERY_PLUGGED_USB -> "Cổng USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Sạc không dây"
            else -> "Đang sạc"
        }
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        return IslandContent(
            Kind.BATTERY, "Pin", "Đang sạc", text = "$pct%",
            extra = "$src • ${String.format(Locale.US, "%.1f", temp)}°C",
            percent = pct,
            actions = listOf(IslandAction("Đóng", Style.NEUTRAL) {})
        )
    }

    // ---------------------------------------------------------------- receiver: sạc, tai nghe, bluetooth

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (isInitialStickyBroadcast) return
            when (intent.action) {
                Intent.ACTION_POWER_CONNECTED -> post(chargingContent(batteryPercent()))
                Intent.ACTION_BATTERY_LOW -> post(
                    IslandContent(
                        Kind.BATTERY, "Pin", "Pin yếu", text = "${batteryPercent()}%",
                        percent = batteryPercent(),
                        actions = listOf(IslandAction("Đóng", Style.NEUTRAL) {})
                    )
                )
                AudioManager.ACTION_HEADSET_PLUG -> wired(intent)
                BluetoothDevice.ACTION_ACL_CONNECTED -> bluetooth(intent, true)
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> bluetooth(intent, false)
            }
        }
    }

    private fun wired(i: Intent) {
        val plugged = i.getIntExtra("state", 0) == 1
        val mic = i.getIntExtra("microphone", 0) == 1
        post(
            if (plugged) {
                IslandContent(
                    Kind.HEADSET, "Âm thanh", "Tai nghe có dây",
                    text = if (mic) "Đã kết nối • có micro" else "Đã kết nối",
                    emoji = "🎧", actions = listOf(IslandAction("Đóng", Style.NEUTRAL) {})
                )
            } else {
                IslandContent(Kind.HEADSET, "Âm thanh", "Đã rút tai nghe", emoji = "🎧")
            }
        )
    }

    @Suppress("DEPRECATION")
    private fun bluetooth(i: Intent, connected: Boolean) {
        val d: BluetoothDevice? = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        val cls = try {
            d?.bluetoothClass
        } catch (_: SecurityException) {
            null
        }
        // Chỉ hiện với thiết bị âm thanh (tai nghe, loa). Không đọc được loại thì vẫn hiện.
        if (cls != null && cls.majorDeviceClass != BluetoothClass.Device.Major.AUDIO_VIDEO) return
        val raw = try {
            d?.name
        } catch (_: SecurityException) {
            null
        }
        val name = raw ?: "Tai nghe Bluetooth"
        post(
            if (connected) {
                IslandContent(
                    Kind.HEADSET, "Bluetooth", name, text = "Đã kết nối", emoji = "🎧",
                    actions = listOf(
                        IslandAction("Cài đặt", Style.NEUTRAL) {
                            startActivity(
                                Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        },
                        IslandAction("Đóng", Style.NEUTRAL) {}
                    )
                )
            } else {
                IslandContent(Kind.HEADSET, "Bluetooth", name, text = "Đã ngắt kết nối", emoji = "🎧")
            }
        )
    }

    // ---------------------------------------------------------------- đèn pin

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            torchId = cameraId
            if (enabled == torchOn) return
            torchOn = enabled
            if (enabled) {
                if (!Config.on(this@IslandService, Config.F_TORCH)) return
                val c = torchContent()
                live = c
                post(c)
            } else {
                if (live?.kind == Kind.TORCH) live = null
                settle()
            }
        }
    }

    private fun torchContent() = IslandContent(
        Kind.TORCH, "Đèn pin", "Đèn pin đang bật", text = "Chạm để mở bảng điều khiển",
        emoji = "🔦", compactText = "Bật",
        actions = listOf(
            IslandAction("Tắt đèn pin", Style.DANGER, closes = false) {
                torchId?.let { id ->
                    getSystemService(CameraManager::class.java).setTorchMode(id, false)
                }
            }
        )
    )

    // ---------------------------------------------------------------- cuộc gọi

    @Suppress("DEPRECATION")
    private val phoneListener = object : PhoneStateListener() {
        override fun onCallStateChanged(state: Int, phoneNumber: String?) {
            handleCall(state, phoneNumber)
        }
    }

    /** Gọi lại được nhiều lần; chạy được khi đã cấp quyền Điện thoại. */
    fun startCalls() {
        if (callsStarted) return
        try {
            @Suppress("DEPRECATION")
            getSystemService(TelephonyManager::class.java)
                .listen(phoneListener, PhoneStateListener.LISTEN_CALL_STATE)
            callsStarted = true
        } catch (_: SecurityException) {
        }
    }

    /** NotifListener báo tên người gọi lấy từ thông báo cuộc gọi của app Điện thoại. */
    fun onCallNotification(name: String) {
        handler.post {
            if (name.isBlank()) return@post
            callerName = name
            if (ringing != null) {
                ringing = ringingContent()
                display(ringing!!, Level.PANEL)
            }
        }
    }

    private fun handleCall(state: Int, number: String?) {
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                if (!allowed(Kind.CALL)) return
                if (callerName == null && !number.isNullOrBlank()) callerName = number
                val r = ringingContent()
                ringing = r
                handler.removeCallbacks(settleTask)
                display(r, Level.PANEL)
            }
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                ringing = null
                if (!allowed(Kind.CALL)) return
                callStart = System.currentTimeMillis()
                val c = activeCallContent()
                live = c
                post(c)
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                val had = ringing != null || live?.kind == Kind.CALL
                ringing = null
                callerName = null
                if (live?.kind == Kind.CALL) live = null
                if (had) {
                    post(IslandContent(Kind.CALL, "Điện thoại", "Cuộc gọi đã kết thúc", emoji = "📞"))
                } else {
                    settle()
                }
            }
        }
    }

    private fun ringingContent() = IslandContent(
        Kind.CALL, "Điện thoại", callerName ?: "Cuộc gọi đến", text = "Cuộc gọi đến", emoji = "📞",
        actions = listOf(
            IslandAction("Từ chối", Style.DANGER, closes = false) { endCall() },
            IslandAction("Trả lời", Style.SUCCESS, closes = false) { answerCall() }
        )
    )

    private fun activeCallContent() = IslandContent(
        Kind.CALL, "Điện thoại", callerName ?: "Đang trong cuộc gọi", text = "Đang gọi", emoji = "📞",
        compactText = "00:00",
        actions = listOf(IslandAction("Kết thúc", Style.DANGER, closes = false) { endCall() })
    )

    private fun answerCall() {
        try {
            getSystemService(TelecomManager::class.java).acceptRingingCall()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Cần cấp quyền Điện thoại trong app", Toast.LENGTH_LONG).show()
        }
    }

    private fun endCall() {
        if (Build.VERSION.SDK_INT < 28) {
            Toast.makeText(this, "Máy này chưa hỗ trợ cúp máy từ đảo", Toast.LENGTH_LONG).show()
            return
        }
        try {
            getSystemService(TelecomManager::class.java).endCall()
        } catch (e: SecurityException) {
            Toast.makeText(this, "Cần cấp quyền Điện thoại trong app", Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------- nhạc

    private var msm: MediaSessionManager? = null
    private var mediaStarted = false
    private var lastController: MediaController? = null
    private val tracked = HashMap<MediaSession.Token, Pair<MediaController, MediaController.Callback>>()
    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> hook(list) }

    /** Gọi lại được nhiều lần; chạy được khi đã cấp quyền truy cập thông báo. */
    fun startMedia() {
        if (mediaStarted) return
        val comp = ComponentName(this, NotifListener::class.java)
        try {
            val m = getSystemService(MediaSessionManager::class.java)
            m.addOnActiveSessionsChangedListener(sessionsListener, comp, handler)
            msm = m
            mediaStarted = true
            hook(m.getActiveSessions(comp))
        } catch (_: SecurityException) {
        }
    }

    private fun isPlaying(c: MediaController) = c.playbackState?.state == PlaybackState.STATE_PLAYING

    private fun hook(list: List<MediaController>?) {
        val sessions = list.orEmpty()
        val tokens = sessions.map { it.sessionToken }.toSet()
        tracked.keys.filter { it !in tokens }.forEach { t ->
            tracked.remove(t)?.let { (old, cb) -> old.unregisterCallback(cb) }
        }
        for (c in sessions) {
            if (tracked.containsKey(c.sessionToken)) continue
            val cb = object : MediaController.Callback() {
                var lastTitle: String? = c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                var wasPlaying = isPlaying(c)

                override fun onMetadataChanged(metadata: MediaMetadata?) {
                    val t = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                    if (t != null && t != lastTitle) {
                        lastTitle = t
                        if (isPlaying(c)) showMusic(c)
                    }
                }

                override fun onPlaybackStateChanged(state: PlaybackState?) {
                    val p = state?.state == PlaybackState.STATE_PLAYING
                    if (p && !wasPlaying) showMusic(c)
                    wasPlaying = p
                    recheckMusic()
                }
            }
            c.registerCallback(cb, handler)
            tracked[c.sessionToken] = c to cb
        }
        recheckMusic()
    }

    /** Đang phát (kể cả đang tải đệm) thì coi là đang phát để tránh nhấp nháy. */
    private fun isActive(c: MediaController): Boolean {
        val st = c.playbackState?.state
        return st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING
    }

    private fun playingController(): MediaController? {
        val last = lastController
        if (last != null && tracked.containsKey(last.sessionToken) && isActive(last)) return last
        return tracked.values.map { it.first }.firstOrNull { isActive(it) }
    }

    private val musicCheck = Runnable {
        if (playingController() == null && current?.kind == Kind.MUSIC && level == Level.COMPACT) settle()
    }

    /** Nhạc/video bắt đầu thì đảo hiện và ở lại; dừng phát (sau ~1 giây) thì đảo ẩn. */
    private fun recheckMusic() {
        handler.removeCallbacks(musicCheck)
        if (!allowed(Kind.MUSIC)) return
        val playing = playingController() != null
        if (playing) {
            if (current == null || (level == Level.COMPACT && current?.kind != Kind.MUSIC)) settle()
        } else if (current?.kind == Kind.MUSIC && level == Level.COMPACT) {
            handler.postDelayed(musicCheck, 1200)
        }
    }

    private fun musicContent(c: MediaController): IslandContent? {
        val m = c.metadata ?: return null
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return null
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
        val pm = packageManager
        val icon: Drawable? = art?.let { BitmapDrawable(resources, it) }
            ?: try {
                pm.getApplicationIcon(c.packageName)
            } catch (_: Exception) {
                null
            }
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(c.packageName, 0)).toString()
        } catch (_: Exception) {
            "Nhạc"
        }
        val playing = isPlaying(c)
        return IslandContent(
            Kind.MUSIC, label, title, text = artist, icon = icon,
            emoji = "🎵", compactText = title.take(14),
            actions = listOf(
                IslandAction("", Style.ICON, android.R.drawable.ic_media_previous, false) {
                    c.transportControls.skipToPrevious()
                },
                IslandAction(
                    "", Style.ICON_PRIMARY,
                    if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                    false
                ) {
                    if (isPlaying(c)) c.transportControls.pause() else c.transportControls.play()
                },
                IslandAction("", Style.ICON, android.R.drawable.ic_media_next, false) {
                    c.transportControls.skipToNext()
                }
            )
        )
    }

    private fun showMusic(c: MediaController) {
        lastController = c
        musicContent(c)?.let { post(it) }
    }

    private fun refreshMusic() {
        val c = lastController ?: return
        if (current?.kind != Kind.MUSIC || level == Level.COMPACT) return
        musicContent(c)?.let { display(it, level) }
    }

    // ---------------------------------------------------------------- thử hiệu ứng

    fun demo(what: String) {
        val icon = try {
            packageManager.getApplicationIcon(packageName)
        } catch (_: Exception) {
            null
        }
        when (what) {
            "notif" -> post(
                IslandContent(
                    Kind.NOTIF, "Tin nhắn", "Minh Anh",
                    "Tối nay đi cà phê không? Mình đặt bàn lúc 7 giờ rồi, nhớ mang theo laptop nhé!",
                    icon = icon,
                    actions = listOf(
                        IslandAction("Mở", Style.PRIMARY) {},
                        IslandAction("Trả lời", Style.NEUTRAL) {},
                        IslandAction("Bỏ qua", Style.NEUTRAL) {}
                    )
                )
            )
            "charge" -> post(chargingContent(batteryPercent()))
            "headset" -> post(
                IslandContent(
                    Kind.HEADSET, "Bluetooth", "Tai nghe của bạn", text = "Đã kết nối", emoji = "🎧",
                    actions = listOf(IslandAction("Đóng", Style.NEUTRAL) {})
                )
            )
            "clock" -> handler.post {
                display(clockContent(), Level.INFO)
                schedule(Level.INFO)
            }
            "call" -> handler.post {
                if (!allowed(Kind.CALL)) return@post
                val r = IslandContent(
                    Kind.CALL, "Điện thoại", "Minh Anh", text = "Cuộc gọi đến", emoji = "📞",
                    actions = listOf(
                        IslandAction("Từ chối", Style.DANGER) { ringing = null },
                        IslandAction("Trả lời", Style.SUCCESS) { ringing = null }
                    )
                )
                ringing = r
                display(r, Level.PANEL)
                handler.postDelayed({
                    if (ringing === r) {
                        ringing = null
                        settle()
                    }
                }, 8000)
            }
            "torch" -> {
                if (!allowed(Kind.TORCH)) return
                val c = IslandContent(
                    Kind.TORCH, "Đèn pin", "Đèn pin đang bật", text = "Chạm để mở bảng điều khiển",
                    emoji = "🔦", compactText = "Bật",
                    actions = listOf(IslandAction("Tắt đèn pin", Style.DANGER) { live = null })
                )
                live = c
                post(c)
                handler.postDelayed({
                    if (live === c) {
                        live = null
                        settle()
                    }
                }, 12000)
            }
        }
    }

    // ---------------------------------------------------------------- notification của chính service

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "VORAXIS", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, "island")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("VORAXIS đang chạy")
            .setOngoing(true)
            .build()
    }
}
