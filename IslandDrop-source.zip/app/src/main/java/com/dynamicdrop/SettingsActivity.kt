package com.dynamicdrop

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView

class SettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = Ui.dp(this, 20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, Ui.dp(this@SettingsActivity, 24), pad, Ui.dp(this@SettingsActivity, 36))
        }

        // ---- Thanh tiêu đề
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val back = Ui.button(this, "‹", Ui.CHIP, 44, 22f) { finish() }
        bar.addView(back, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)).apply {
            marginEnd = Ui.dp(this@SettingsActivity, 14)
        })
        bar.addView(Ui.text(this, "Cài đặt", 24f, bold = true))
        root.addView(bar, Ui.lp(bottom = Ui.dp(this, 20)))

        val refresh: () -> Unit = { IslandBus.service?.refresh() }

        // ---- Hiển thị
        root.addView(Ui.sectionTitle(this, "Hiển thị trên đảo"))
        val show = Ui.card(this)
        show.addView(Ui.switchRow(this, "Đảo dọc", "Rớt xuống thành thanh dọc từ camera, bấm để mở rộng", Config.F_VERT, refresh))
        show.addView(Ui.switchRow(this, "Thông báo", "Rớt xuống và hiện toàn bộ nội dung", Config.F_NOTIF, refresh))
        show.addView(Ui.switchRow(this, "Nhạc đang phát", "Tên bài, nút điều khiển", Config.F_MUSIC, refresh))
        show.addView(Ui.switchRow(this, "Sạc pin", "Hình máy cắm dây sạc", Config.F_CHARGE, refresh))
        show.addView(Ui.switchRow(this, "Cuộc gọi đến", "Tự mở rộng, có nút nghe/từ chối", Config.F_CALL, refresh))
        show.addView(Ui.switchRow(this, "Tai nghe", "Có dây và Bluetooth", Config.F_HEADSET, refresh))
        show.addView(Ui.switchRow(this, "Đèn pin", "Hiện khi bật, bấm để tắt", Config.F_TORCH, refresh))
        show.addView(Ui.switchRow(this, "Giờ cạnh camera", "Hiện giờ lúc bình thường, bấm để xem ngày", Config.F_CLOCK, refresh))
        root.addView(show, Ui.lp(bottom = Ui.dp(this, 18)))

        // ---- Thông báo hệ thống
        root.addView(Ui.sectionTitle(this, "Thông báo hệ thống"))
        val sys = Ui.card(this)
        sys.addView(
            Ui.switchRow(
                this, "Chặn banner của hệ thống",
                "Chặn cứng: mọi thông báo bị xóa khỏi hệ thống ngay khi đến, chỉ còn hiện trên đảo. Không còn lưu trong thanh thông báo, bấm Mở trên đảo để vào app.",
                Config.F_BLOCK, refresh
            )
        )
        root.addView(sys, Ui.lp(bottom = Ui.dp(this, 18)))

        // ---- Thời gian
        root.addView(Ui.sectionTitle(this, "Thời gian"))
        val time = Ui.card(this)
        time.addView(Ui.slider(this, "Tự thu lại sau", Config.INFO_SEC, 2, 15, 5f, "giây") {})
        root.addView(time, Ui.lp(bottom = Ui.dp(this, 18)))

        // ---- Vị trí camera
        root.addView(Ui.sectionTitle(this, "Căn vị trí camera"))
        val cam = Ui.card(this)
        cam.addView(Ui.text(this, "Kéo cho viên thuốc đen che vừa khít lỗ camera.", 12.5f, Ui.SUB))
        val after: () -> Unit = {
            IslandBus.service?.refresh()
            IslandBus.service?.demo("notif")
        }
        cam.addView(Ui.slider(this, "Cách mép trái", Config.CX, 0, 100, 26f, "dp", after))
        cam.addView(Ui.slider(this, "Cách mép trên", Config.CY, 0, 60, 20f, "dp", after))
        cam.addView(Ui.slider(this, "Kích thước lỗ", Config.SIZE, 10, 44, 22f, "dp", after))
        root.addView(cam)

        setContentView(ScrollView(this).apply {
            addView(root, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        })
    }
}
