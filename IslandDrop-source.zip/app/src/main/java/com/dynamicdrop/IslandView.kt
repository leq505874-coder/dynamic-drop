package com.dynamicdrop

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * Viên thuốc đen vẽ đè lên lỗ camera góc trên bên trái.
 * COMPACT = viên nhỏ cạnh camera, INFO = rớt xuống hiện thông tin, PANEL = bảng có nút.
 */
class IslandView(
    ctx: Context,
    private val wm: WindowManager,
    private val onTap: () -> Unit,
    private val onAction: (IslandAction) -> Unit
) : FrameLayout(ctx) {

    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Float) = (v * density).toInt()
    private fun dp(v: Int) = (v * density).toInt()

    private val holeD = dp(Config.size(ctx))
    private val holeLeft = (dp(Config.cx(ctx)) - holeD / 2).coerceAtLeast(0)
    private val holeTop = (dp(Config.cy(ctx)) - holeD / 2).coerceAtLeast(0)
    private val panelW = minOf(ctx.resources.displayMetrics.widthPixels - holeLeft - dp(12), dp(360))

    private val gray = Color.parseColor("#9A9A9A")
    private val lightGray = Color.parseColor("#C4C4C8")
    private val cNeutral = Color.parseColor("#2C2C2E")
    private val cPrimary = Color.parseColor("#0A84FF")
    private val cDanger = Color.parseColor("#FF453A")
    private val cSuccess = Color.parseColor("#30D158")
    private val cIcon = Color.parseColor("#38FFFFFF")

    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }

    private val lp = WindowManager.LayoutParams(
        holeD,
        holeD,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = holeLeft
        y = holeTop
        if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private var attached = false
    private var body: View? = null
    private var curW = holeD
    private var curH = holeD
    private var lastKey = ""
    private var radiusCap = dp(28)
    private val vertW = minOf(dp(92), panelW)
    private var anim: ValueAnimator? = null
    private var compactTv: TextView? = null

    init {
        background = bg
        outlineProvider = ViewOutlineProvider.BACKGROUND
        clipToOutline = true
        setOnClickListener { onTap() }
    }

    // ---------------------------------------------------------------- API

    fun render(c: IslandContent, level: Level) {
        compactTv = null
        // Đảo dọc: mức INFO rớt xuống thành thanh dọc hẹp; bấm vào mới bung thành bảng rộng (PANEL).
        val vertical = level == Level.INFO && Config.on(context, Config.F_VERT)
        radiusCap = if (vertical) dp(40) else dp(28)
        val nb: View = when {
            level == Level.COMPACT -> buildCompact(c)
            vertical -> buildVertical(c)
            else -> buildCard(c, level == Level.PANEL)
        }

        val w: Int
        if (level == Level.COMPACT) {
            nb.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(holeD, View.MeasureSpec.EXACTLY)
            )
            w = nb.measuredWidth
        } else {
            w = if (vertical) vertW else panelW
            nb.measure(
                View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
        }
        val h = nb.measuredHeight.coerceAtLeast(holeD)

        val key = "${c.kind}-$level-$vertical"
        val same = key == lastKey && attached
        lastKey = key

        body?.let { removeView(it) }
        body = nb
        addView(nb, FrameLayout.LayoutParams(w, h, Gravity.TOP or Gravity.START))
        nb.alpha = if (same) 1f else 0f

        if (!attached) {
            setSize(holeD, holeD)
            try {
                wm.addView(this, lp)
                attached = true
            } catch (e: Exception) {
                return
            }
        }
        animateTo(w, h, same)
    }

    /** Cập nhật chữ trong viên nhỏ (giờ, đồng hồ cuộc gọi) mà không chạy lại hiệu ứng. */
    fun updateCompactText(t: String) {
        compactTv?.let { if (it.text.toString() != t) it.text = t }
    }

    fun hide(onGone: () -> Unit = {}) {
        anim?.cancel()
        val sw = curW
        val sh = curH
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 260
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener {
            val t = it.animatedValue as Float
            setSize(lerp(sw, holeD, t), lerp(sh, holeD, t))
            body?.alpha = (1f - t * 2f).coerceIn(0f, 1f)
        }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled) {
                    remove()
                    onGone()
                }
            }
        })
        anim = a
        a.start()
    }

    fun destroy() {
        anim?.cancel()
        remove()
    }

    // ---------------------------------------------------------------- animation

    private fun lerp(a: Int, b: Int, f: Float) = (a + (b - a) * f).toInt()

    private fun setSize(w: Int, h: Int) {
        curW = w.coerceAtLeast(holeD)
        curH = h.coerceAtLeast(holeD)
        lp.width = curW
        lp.height = curH
        bg.cornerRadius = minOf(minOf(curW, curH) / 2f, radiusCap.toFloat())
        if (attached) {
            try {
                wm.updateViewLayout(this, lp)
                invalidateOutline()
            } catch (_: Exception) {
            }
        }
    }

    private fun animateTo(tw: Int, th: Int, sameContent: Boolean) {
        anim?.cancel()
        val sw = curW
        val sh = curH
        val grow = tw.toLong() * th > sw.toLong() * sh
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = if (grow) 520L else 320L
        a.interpolator = if (grow) OvershootInterpolator(0.9f) else DecelerateInterpolator()
        a.addUpdateListener {
            val t = it.animatedValue as Float
            setSize(lerp(sw, tw, t), lerp(sh, th, t))
            if (!sameContent) body?.alpha = ((t - 0.3f) * 1.5f).coerceIn(0f, 1f)
        }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled) {
                    setSize(tw, th)
                    body?.alpha = 1f
                }
            }
        })
        anim = a
        a.start()
    }

    private fun remove() {
        if (attached) {
            try {
                wm.removeView(this)
            } catch (_: Exception) {
            }
            attached = false
        }
    }

    // ---------------------------------------------------------------- dựng nội dung

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false, lines: Int = 1) =
        TextView(context).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            maxLines = lines
            ellipsize = TextUtils.TruncateAt.END
        }

    private fun pill(color: Int, radiusPx: Int): Drawable {
        val shape = GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx.toFloat()
        }
        return RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), shape, null)
    }

    /** Viên nhỏ cạnh camera: [lỗ camera][emoji][chữ]. */
    private fun buildCompact(c: IslandContent): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(holeD + dp(6), 0, dp(12), 0)
        }
        if (c.emoji.isNotBlank()) {
            row.addView(
                tv(c.emoji, 13f, Color.WHITE),
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(4) }
            )
        }
        val t = tv(c.compactText, 13f, Color.WHITE, bold = true)
        t.minWidth = dp(34)
        row.addView(t)
        compactTv = t
        return row
    }

    /** Thẻ lớn: INFO (chỉ thông tin) hoặc PANEL (thêm hàng nút). */
    private fun buildCard(c: IslandContent, panel: Boolean): View {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(16))
        }

        // Hàng đầu nằm ngang với camera: tên app + giờ
        val header = LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(holeD + dp(10), 0, dp(18), 0)
        }
        header.addView(
            tv(c.label, 11f, gray),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        header.addView(tv(nowTime(), 11f, gray))
        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, holeD))

        val row = LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(4), dp(18), 0)
        }

        when (c.kind) {
            Kind.BATTERY -> {
                val cv = ChargeView(context).apply { percent = c.percent }
                row.addView(cv, LinearLayout.LayoutParams(dp(44), dp(58)).apply { marginEnd = dp(16) })
            }
            Kind.CLOCK -> {}
            Kind.NOTIF, Kind.MUSIC -> {
                val icon = ImageView(context).apply {
                    setImageDrawable(c.icon)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    outlineProvider = object : ViewOutlineProvider() {
                        override fun getOutline(view: View, outline: Outline) {
                            outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
                        }
                    }
                    clipToOutline = true
                }
                row.addView(icon, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(14) })
            }
            else -> {
                val e = tv(c.emoji, 30f, Color.WHITE).apply { gravity = Gravity.CENTER }
                row.addView(e, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(14) })
            }
        }

        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val bigTitle = c.kind == Kind.CLOCK
        col.addView(
            tv(
                c.title,
                if (bigTitle) 36f else 16f,
                Color.WHITE,
                bold = true,
                lines = if (panel && c.kind == Kind.NOTIF) 2 else 1
            )
        )
        if (c.text.isNotBlank()) {
            col.addView(
                tv(
                    c.text,
                    if (c.kind == Kind.BATTERY) 22f else 13.5f,
                    if (c.kind == Kind.BATTERY) Color.WHITE else lightGray,
                    bold = c.kind == Kind.BATTERY,
                    lines = if (panel) 8 else 5
                ).apply { if (c.kind == Kind.NOTIF) setPadding(0, dp(2), 0, 0) }
            )
        }
        if (c.extra.isNotBlank()) {
            col.addView(tv(c.extra, 12f, gray, lines = 2).apply { setPadding(0, dp(3), 0, 0) })
        }
        if (c.kind == Kind.BATTERY) {
            val bar = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = c.percent
                progressTintList = ColorStateList.valueOf(if (c.percent <= 20) cDanger else cSuccess)
            }
            col.addView(
                bar,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)).apply {
                    topMargin = dp(8)
                }
            )
        }
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Hàng nút chỉ hiện khi bấm vào đảo (PANEL)
        if (panel && c.actions.isNotEmpty()) {
            val br = LinearLayout(context).apply {
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(16), dp(14), 0)
            }
            for (a in c.actions) {
                val iconBtn = a.iconRes != 0
                val lpBtn = if (iconBtn) {
                    LinearLayout.LayoutParams(dp(60), dp(48))
                } else {
                    LinearLayout.LayoutParams(0, dp(44), 1f)
                }
                lpBtn.setMargins(dp(4), 0, dp(4), 0)
                br.addView(makeButton(a), lpBtn)
            }
            root.addView(br, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        return root
    }

    /** Thanh dọc: [camera + giờ nhỏ] / hình / tiêu đề / nội dung ngắn / vạch "bấm để mở rộng". */
    private fun buildVertical(c: IslandContent): View {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), 0, dp(8), dp(12))
        }
        val header = LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setPadding((holeD - dp(8)).coerceAtLeast(0), 0, dp(4), 0)
            addView(tv(nowTime(), 10f, gray))
        }
        root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, holeD))

        val graphic: View? = when (c.kind) {
            Kind.BATTERY -> ChargeView(context).apply { percent = c.percent }
            Kind.CLOCK -> null
            Kind.NOTIF, Kind.MUSIC -> ImageView(context).apply {
                setImageDrawable(c.icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, dp(11).toFloat())
                    }
                }
                clipToOutline = true
            }
            else -> tv(c.emoji, 28f, Color.WHITE).apply { gravity = Gravity.CENTER }
        }
        if (graphic != null) {
            val battery = c.kind == Kind.BATTERY
            root.addView(
                graphic,
                LinearLayout.LayoutParams(if (battery) dp(36) else dp(40), if (battery) dp(48) else dp(40))
                    .apply { topMargin = dp(6) }
            )
        }

        root.addView(
            tv(c.title, if (c.kind == Kind.CLOCK) 24f else 12f, Color.WHITE, bold = true, lines = 2)
                .apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(8) }
        )
        val battery = c.kind == Kind.BATTERY
        val sub = if (battery) "${c.percent}%" else c.text
        if (sub.isNotBlank()) {
            root.addView(
                tv(sub, if (battery) 18f else 10.5f, if (battery) Color.WHITE else lightGray, bold = battery, lines = 3)
                    .apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { topMargin = dp(3) }
            )
        }

        val grip = View(context).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#55FFFFFF"))
                cornerRadius = dp(2).toFloat()
            }
        }
        root.addView(grip, LinearLayout.LayoutParams(dp(26), dp(4)).apply { topMargin = dp(10) })
        return root
    }

    private fun makeButton(a: IslandAction): View {
        if (a.iconRes != 0) {
            val primary = a.style == Style.ICON_PRIMARY
            return ImageButton(context).apply {
                setImageResource(a.iconRes)
                setColorFilter(if (primary) Color.BLACK else Color.WHITE)
                background = pill(if (primary) Color.WHITE else cIcon, dp(24))
                setOnClickListener { onAction(a) }
            }
        }
        val color = when (a.style) {
            Style.PRIMARY -> cPrimary
            Style.DANGER -> cDanger
            Style.SUCCESS -> cSuccess
            else -> cNeutral
        }
        return TextView(context).apply {
            text = a.label
            gravity = Gravity.CENTER
            textSize = 13.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(8), 0)
            background = pill(color, dp(22))
            setOnClickListener { onAction(a) }
        }
    }
}
