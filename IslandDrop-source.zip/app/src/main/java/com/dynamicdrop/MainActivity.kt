package com.dynamicdrop

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var permCard: LinearLayout
    private lateinit var toggle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = Ui.dp(this, 20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, Ui.dp(this@MainActivity, 28), pad, Ui.dp(this@MainActivity, 36))
        }

        // ---- Đầu trang: avatar + tên
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            Ui.roundClip(this, Ui.dp(this@MainActivity, 18).toFloat())
        }
        header.addView(logo, LinearLayout.LayoutParams(Ui.dp(this, 68), Ui.dp(this, 68)).apply {
            marginEnd = Ui.dp(this@MainActivity, 16)
        })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(Ui.text(this, "VORAXIS", 26f, bold = true))
        titles.addView(Ui.text(this, "Dynamic Island + hố đen", 13f, Ui.SUB))
        header.addView(titles)
        root.addView(header, Ui.lp(bottom = Ui.dp(this, 22)))

        // ---- Quyền
        root.addView(Ui.sectionTitle(this, "Quyền truy cập"))
        permCard = Ui.card(this)
        root.addView(permCard, Ui.lp(bottom = Ui.dp(this, 18)))

        // ---- Bật / tắt
        toggle = Ui.button(this, "", Ui.GREEN, 56, 17f) { toggleService() }
        root.addView(toggle, Ui.lp(h = Ui.dp(this, 56), bottom = Ui.dp(this, 22)))

        // ---- Thử hiệu ứng
        root.addView(Ui.sectionTitle(this, "Thử hiệu ứng"))
        val demo = Ui.card(this)
        fun chipRow(vararg items: Pair<String, String>) {
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER }
            for ((label, key) in items) {
                val chip = Ui.button(this, label, Ui.CHIP, 42, 13.5f) { runDemo(key) }
                r.addView(chip, LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1f).apply {
                    setMargins(Ui.dp(this@MainActivity, 4), Ui.dp(this@MainActivity, 4), Ui.dp(this@MainActivity, 4), Ui.dp(this@MainActivity, 4))
                })
            }
            demo.addView(r)
        }
        chipRow("Thông báo" to "notif", "Sạc" to "charge", "Cuộc gọi" to "call")
        chipRow("Tai nghe" to "headset", "Đèn pin" to "torch", "Giờ" to "clock")
        root.addView(demo, Ui.lp(bottom = Ui.dp(this, 18)))

        // ---- Cài đặt
        root.addView(Ui.button(this, "Cài đặt", Ui.CHIP, 50, 15f) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }, Ui.lp(h = Ui.dp(this, 50)))

        setContentView(ScrollView(this).apply {
            addView(root, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
        // Vừa quay lại từ màn cấp quyền: cho service thử bắt đầu theo dõi nhạc và cuộc gọi.
        IslandBus.service?.startMedia()
        IslandBus.service?.startCalls()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        refresh()
        IslandBus.service?.startCalls()
    }

    private fun refresh() {
        permCard.removeAllViews()
        permCard.addView(Ui.permRow(this, "Trợ năng (khuyên bật)", "Để đảo nằm trên thanh trạng thái và bấm được", Perms.accessibility(this)) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        permCard.addView(Ui.permRow(this, "Hiển thị trên ứng dụng khác", "Dự phòng nếu không bật Trợ năng", Perms.overlay(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        permCard.addView(Ui.permRow(this, "Truy cập thông báo", "Hiện thông báo và bài nhạc đang phát", Perms.listener(this)) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        permCard.addView(Ui.permRow(this, "Điện thoại", "Hiện và nghe/cúp cuộc gọi đến", Perms.phone(this)) {
            requestPermissions(Perms.phonePerms, 1)
        })
        permCard.addView(Ui.permRow(this, "Bluetooth", "Hiện tên tai nghe Bluetooth", Perms.bluetooth(this)) {
            requestPermissions(arrayOf("android.permission.BLUETOOTH_CONNECT"), 2)
        })
        permCard.addView(Ui.permRow(this, "Thông báo của app", "Giữ đảo chạy nền ổn định", Perms.post(this)) {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
            }
        })

        val on = Config.enabled(this)
        toggle.text = if (on) "Tắt đảo" else "Bật đảo"
        toggle.background = Ui.ripple(if (on) Ui.RED else Ui.GREEN, Ui.dp(this, 28).toFloat())
    }

    private fun toggleService() {
        if (Config.enabled(this)) {
            stopService(Intent(this, IslandService::class.java))
            Config.setEnabled(this, false)
        } else {
            if (!Perms.overlay(this) && !Perms.accessibility(this)) {
                Toast.makeText(this, "Bật Trợ năng hoặc cấp quyền hiển thị trên ứng dụng khác trước đã", Toast.LENGTH_LONG).show()
                return
            }
            startForegroundService(Intent(this, IslandService::class.java))
            Config.setEnabled(this, true)
        }
        refresh()
    }

    private fun runDemo(key: String) {
        val s = IslandBus.service
        if (s == null) {
            Toast.makeText(this, "Bật đảo trước đã", Toast.LENGTH_SHORT).show()
            return
        }
        s.demo(key)
    }
}
