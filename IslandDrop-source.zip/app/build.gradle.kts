plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "vn.quangda14.islanddrop"
    compileSdk = 35
    defaultConfig {
        applicationId = "vn.quangda14.islanddrop"
        minSdk = 26
        targetSdk = 32
        versionCode = 1
        versionName = "1.0"
    }
}
