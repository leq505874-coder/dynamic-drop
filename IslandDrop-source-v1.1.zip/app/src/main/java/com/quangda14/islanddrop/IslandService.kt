package com.quangda14.islanddrop

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private var island: LinearLayout? = null
    private var expanded = false
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { IslandPrefs(this) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val label = when (intent?.action) {
            ACTION_CHARGING -> "⚡  Đang sạc pin"
            ACTION_NOTIFICATION -> intent.getStringExtra("text") ?: "Thông báo mới"
            ACTION_HEADSET -> "🎧  Tai nghe đã kết nối"
            else -> "IslandDrop • Chạm để mở"
        }
        show(label, intent?.action == ACTION_DEMO || intent?.action == ACTION_SHOW || intent?.action == ACTION_NOTIFICATION)
        return START_NOT_STICKY
    }

    private fun show(label: String, open: Boolean) {
        removeIsland()
        expanded = open
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = dp(24).toFloat(); setStroke(dp(1), 0xFF252631.toInt()) }
            elevation = dp(12).toFloat()
        }
        val title = TextView(this).apply { text = label; setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; maxLines = 3 }
        container.addView(title)
        if (open) {
            val detail = TextView(this).apply { text = "━━━━━━━━━━━━\n♫  Nhạc     ◷  Hẹn giờ\n🔋  Pin       🎧  Tai nghe\n⚙  Settings"; setTextColor(0xFFE7E7EF.toInt()); textSize = 12f; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
            container.addView(detail)
        }
        val params = WindowManager.LayoutParams(
            if (open) dp(prefs.widthDp + 50) else dp(prefs.widthDp.coerceAtMost(180)),
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = dp(18 + prefs.offsetDp).coerceAtLeast(0)
            y = dp(3)
        }
        container.setOnClickListener {
            expanded = !expanded
            show(if (expanded) "IslandDrop • Bảng điều khiển" else label, expanded)
        }
        container.alpha = 0f
        container.translationY = -dp(90).toFloat()
        island = container
        try {
            wm.addView(container, params)
            container.animate().alpha(1f).translationY(dp(10).toFloat()).setDuration(420).setInterpolator(OvershootInterpolator(0.85f)).withEndAction {
                container.animate().translationY(0f).setDuration(120).start()
            }.start()
        } catch (_: Exception) { island = null; stopSelf(); return }
        if (prefs.autoClose && !open) handler.postDelayed({ if (!expanded) removeIsland() }, 4500)
    }

    private fun removeIsland() { handler.removeCallbacksAndMessages(null); island?.let { try { wm.removeView(it) } catch (_: Exception) {} }; island = null }
    override fun onDestroy() { removeIsland(); super.onDestroy() }
    companion object {
        const val ACTION_SHOW = "island.show"
        const val ACTION_DEMO = "island.demo"
        const val ACTION_CHARGING = "island.charging"
        const val ACTION_NOTIFICATION = "island.notification"
        const val ACTION_HEADSET = "island.headset"
    }
}
