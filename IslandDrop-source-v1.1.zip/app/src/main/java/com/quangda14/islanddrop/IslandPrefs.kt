package com.quangda14.islanddrop

import android.content.Context

class IslandPrefs(context: Context) {
    private val p = context.getSharedPreferences("islanddrop", Context.MODE_PRIVATE)
    var offsetDp: Int get() = p.getInt("offset", 0); set(v) { p.edit().putInt("offset", v.coerceIn(-40, 40)).apply() }
    var widthDp: Int get() = p.getInt("width", 170); set(v) { p.edit().putInt("width", v.coerceIn(100, 200)).apply() }
    var autoClose: Boolean get() = p.getBoolean("auto", true); set(v) { p.edit().putBoolean("auto", v).apply() }
}
