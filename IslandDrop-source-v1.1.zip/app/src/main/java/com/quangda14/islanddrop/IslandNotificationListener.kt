package com.quangda14.islanddrop

import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class IslandNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val app = extras.getCharSequence("android.title")?.toString().orEmpty()
        val body = extras.getCharSequence("android.text")?.toString().orEmpty()
        val text = listOf(app, body).filter { it.isNotBlank() }.joinToString(" • ").take(180)
        if (text.isBlank()) return
        startService(Intent(this, IslandService::class.java).setAction(IslandService.ACTION_NOTIFICATION).putExtra("text", text))
    }
}
