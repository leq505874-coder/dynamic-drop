package com.quangda14.islanddrop

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class SystemEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = when (intent.action) {
            Intent.ACTION_POWER_CONNECTED -> IslandService.ACTION_CHARGING
            Intent.ACTION_HEADSET_PLUG -> if (intent.getIntExtra("state", 0) == 1) IslandService.ACTION_HEADSET else null
            else -> null
        } ?: return
        try { context.startService(Intent(context, IslandService::class.java).setAction(action)) } catch (_: Exception) {}
    }
}
