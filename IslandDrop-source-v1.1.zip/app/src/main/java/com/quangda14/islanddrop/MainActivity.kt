package com.quangda14.islanddrop

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var root: LinearLayout
    private val purple = 0xFF8B5CF6.toInt()
    private val bg = 0xFF101116.toInt()
    private val card = 0xFF1D1F29.toInt()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() { super.onResume(); if (::status.isInitialized) updateStatus() }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(26), dp(20), dp(24)); setBackgroundColor(bg) }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        val logo = TextView(this).apply { text = "◉  🤖"; textSize = 34f; gravity = Gravity.CENTER; setTextColor(-1) }
        root.addView(logo, matchWrap())
        root.addView(TextView(this).apply { text = "IslandDrop"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(-1); setPadding(0, dp(8), 0, dp(4)) }, matchWrap())
        root.addView(TextView(this).apply { text = "Dynamic Island cho OPPO A53"; textSize = 14f; gravity = Gravity.CENTER; setTextColor(0xFFB7B8C5.toInt()); setPadding(0, 0, 0, dp(20)) }, matchWrap())
        status = TextView(this).apply { textSize = 14f; setTextColor(-1); setPadding(dp(16), dp(14), dp(16), dp(14)); setBackgroundColor(card) }
        root.addView(status, matchWrap())
        addButton("Bật IslandDrop", "Bật overlay và chạy đảo động") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Hãy bật Cho phép hiển thị trên ứng dụng khác rồi quay lại", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, IslandService::class.java).setAction(IslandService.ACTION_SHOW))
                Toast.makeText(this, "IslandDrop đã bật", Toast.LENGTH_SHORT).show()
            }
        }
        addButton("Quyền thông báo", "Cho phép hiển thị thông báo mới") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        addButton("⚙ Settings", "Tùy chỉnh giao diện và hiệu ứng") { showSettings() }
        addButton("Xem trước đảo động", "Thử hiệu ứng rơi từ vị trí camera") {
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else startService(Intent(this, IslandService::class.java).setAction(IslandService.ACTION_DEMO))
        }
        addButton("Tắt đảo động", "Ẩn overlay") { stopService(Intent(this, IslandService::class.java)) }
        root.addView(TextView(this).apply { text = "Lưu ý: quyền cuộc gọi, đèn pin và điều khiển nhạc phụ thuộc API Android và ứng dụng đang phát. IslandDrop không thay đổi phần cứng camera."; textSize = 12f; setTextColor(0xFFAAAAB8.toInt()); setPadding(dp(4), dp(18), dp(4), 0) }, matchWrap())
        updateStatus()
    }

    private fun updateStatus() {
        val overlay = if (Settings.canDrawOverlays(this)) "✓ Đã cấp" else "○ Chưa cấp"
        val enabled = try { Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true } catch (_: Exception) { false }
        val notification = if (enabled) "✓ Đã cấp" else "○ Chưa cấp"
        status.text = "QUYỀN ỨNG DỤNG\n\n$overlay  Hiển thị trên ứng dụng khác\n$notification  Truy cập thông báo"
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        val pos = SeekBar(this).apply { max = 80; progress = IslandPrefs(this@MainActivity).offsetDp + 40 }
        box.addView(TextView(this).apply { text = "Vị trí ngang quanh camera"; textSize = 16f })
        box.addView(pos)
        val size = SeekBar(this).apply { max = 100; progress = IslandPrefs(this@MainActivity).widthDp - 100 }
        box.addView(TextView(this).apply { text = "Chiều rộng đảo động"; textSize = 16f; setPadding(0, dp(12), 0, 0) })
        box.addView(size)
        val auto = CheckBox(this).apply { text = "Tự thu gọn sau vài giây"; isChecked = IslandPrefs(this@MainActivity).autoClose }
        box.addView(auto)
        AlertDialog.Builder(this).setTitle("IslandDrop Settings").setView(box).setNegativeButton("Hủy", null).setPositiveButton("Lưu") { _, _ ->
            IslandPrefs(this).apply { offsetDp = pos.progress - 40; widthDp = size.progress + 100; autoClose = auto.isChecked }
            Toast.makeText(this, "Đã lưu cài đặt", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun addButton(title: String, sub: String, action: () -> Unit) {
        val b = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = rounded(card, 20) }
        b.addView(TextView(this).apply { text = title; textSize = 16f; setTextColor(-1) })
        b.addView(TextView(this).apply { text = sub; textSize = 12f; setTextColor(0xFFB7B8C5.toInt()); setPadding(0, dp(4), 0, 0) })
        b.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(12); root.addView(b, lp)
    }
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), 0xFF30313D.toInt()) }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
}
