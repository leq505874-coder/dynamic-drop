# Dynamic Drop

Dynamic Island giả cho Android: một viên thuốc đen che lỗ camera góc trên bên trái
(làm cho Oppo A53), bung xuống khi có thông báo, đổi bài nhạc hoặc cắm sạc.

## Tính năng
- Thông báo: icon app, tên app, tiêu đề, nội dung. Chạm vào để mở thông báo.
- Nhạc đang phát: tên bài, ca sĩ, nút trước / play-pause / sau.
- Pin: hiện % khi cắm sạc hoặc pin yếu.
- Tự bật lại sau khi khởi động máy (nếu đang bật).

## Cách build

### Cách 1: Android Studio (PC)
Mở thư mục này bằng Android Studio, đợi Gradle sync xong, bấm Run.

### Cách 2: GitHub Actions (chỉ cần điện thoại)
Mỗi lần push lên `main`, tab **Actions → Build APK** sẽ build file APK.
Vào lần chạy mới nhất, tải artifact **DynamicDrop-debug-apk**, giải nén, cài file `.apk`.

## Cài đặt trên máy
1. Mở app, bấm **Cho phép hiển thị trên ứng dụng khác**.
2. Bấm **Cho phép đọc thông báo** và bật Dynamic Drop (cần cho thông báo + nhạc).
3. Bấm **Bật đảo**.
4. Kéo 3 thanh trượt cho viên thuốc che vừa khít lỗ camera, bấm **Thử hiệu ứng**.
   Giá trị mặc định (26 / 20 / 22 dp) chỉ là ước lượng cho Oppo A53, cần chỉnh lại.

## Lưu ý cho Oppo / ColorOS
- Vào Cài đặt → Pin → cho Dynamic Drop **chạy nền không hạn chế** và bật **Tự khởi động**,
  nếu không ColorOS sẽ tắt service.
- Một số bản ColorOS không cho overlay vẽ lên thanh trạng thái. Nếu viên thuốc bị đẩy xuống
  dưới thanh trạng thái, tăng thanh trượt "Cách mép trên" cho khớp hoặc báo lại để đổi cách vẽ.
- Sạc: ColorOS đôi khi chặn broadcast cắm sạc khi app bị đóng băng, xem mục trên.
