package com.dynamicdrop

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Config.enabled(context)) {
            try {
                context.startForegroundService(Intent(context, IslandService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
