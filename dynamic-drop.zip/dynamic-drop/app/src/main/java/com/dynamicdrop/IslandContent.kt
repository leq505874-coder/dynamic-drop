package com.dynamicdrop

import android.app.PendingIntent
import android.graphics.drawable.Drawable
import android.media.session.MediaController

enum class Kind { NOTIF, MUSIC, BATTERY }

data class IslandContent(
    val kind: Kind,
    val label: String,
    val title: String,
    val text: String = "",
    val icon: Drawable? = null,
    val intent: PendingIntent? = null,
    val controller: MediaController? = null,
    val percent: Int = 0,
    val durationMs: Long = 5000
)

/** Cầu nối đơn giản giữa NotifListener / MainActivity và IslandService. */
object IslandBus {
    @Volatile
    var service: IslandService? = null

    fun show(c: IslandContent) {
        service?.show(c)
    }
}
