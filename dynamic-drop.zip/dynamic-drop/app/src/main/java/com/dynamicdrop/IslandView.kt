package com.dynamicdrop

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.session.PlaybackState
import android.os.Build
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * Viên thuốc đen vẽ đè lên lỗ camera góc trên bên trái.
 * Lúc thu lại nó đúng bằng lỗ camera; lúc mở thì bung xuống + sang phải.
 */
class IslandView(
    ctx: Context,
    private val wm: WindowManager,
    private val onTap: (IslandContent) -> Unit
) : FrameLayout(ctx) {

    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Float) = (v * density).toInt()

    private val holeD = dp(Config.size(ctx))
    private val holeLeft = (dp(Config.cx(ctx)) - holeD / 2).coerceAtLeast(0)
    private val holeTop = (dp(Config.cy(ctx)) - holeD / 2).coerceAtLeast(0)
    private val expW = minOf(ctx.resources.displayMetrics.widthPixels - holeLeft - dp(12f), dp(340f))
    private var expH = holeD + dp(76f)

    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }
    private val body = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

    private val lp = WindowManager.LayoutParams(
        holeD,
        holeD,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = holeLeft
        y = holeTop
        if (Build.VERSION.SDK_INT >= 28) {
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private var attached = false
    private var frac = 0f
    private var anim: ValueAnimator? = null
    private var current: IslandContent? = null

    init {
        background = bg
        outlineProvider = ViewOutlineProvider.BACKGROUND
        clipToOutline = true
        addView(body, FrameLayout.LayoutParams(expW, expH, Gravity.TOP or Gravity.START))
        setOnClickListener { current?.let(onTap) }
    }

    // ---------- API ----------

    fun present(c: IslandContent) {
        current = c
        expH = holeD + build(c)
        body.layoutParams = FrameLayout.LayoutParams(expW, expH, Gravity.TOP or Gravity.START)
        if (!attached) {
            render(0f)
            wm.addView(this, lp)
            attached = true
        } else {
            render(frac)
        }
        animateTo(1f)
    }

    fun dismiss(onGone: () -> Unit) {
        animateTo(0f) {
            remove()
            onGone()
        }
    }

    fun destroy() {
        anim?.cancel()
        remove()
    }

    // ---------- animation ----------

    private fun lerp(a: Int, b: Int, f: Float) = (a + (b - a) * f).toInt()

    private fun render(f: Float) {
        frac = f
        lp.width = lerp(holeD, expW, f).coerceAtLeast(holeD)
        lp.height = lerp(holeD, expH, f).coerceAtLeast(holeD)
        val full = dp(28f).toFloat()
        val r = (holeD / 2f + (full - holeD / 2f) * f).coerceAtMost(minOf(lp.width, lp.height) / 2f)
        bg.cornerRadius = r
        body.alpha = ((f - 0.45f) * 2f).coerceIn(0f, 1f)
        if (attached) {
            wm.updateViewLayout(this, lp)
            invalidateOutline()
        }
    }

    private fun animateTo(target: Float, onEnd: (() -> Unit)? = null) {
        anim?.cancel()
        val opening = target > frac
        val a = ValueAnimator.ofFloat(frac, target)
        a.duration = if (opening) 520L else 280L
        a.interpolator = if (opening) OvershootInterpolator(0.9f) else AccelerateInterpolator()
        a.addUpdateListener { render(it.animatedValue as Float) }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled) onEnd?.invoke()
            }
        })
        anim = a
        a.start()
    }

    private fun remove() {
        if (attached) {
            try {
                wm.removeView(this)
            } catch (_: Exception) {
            }
            attached = false
        }
    }

    // ---------- nội dung ----------

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false, lines: Int = 1) =
        TextView(context).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            maxLines = lines
            ellipsize = TextUtils.TruncateAt.END
        }

    /** Dựng nội dung, trả về chiều cao phần thân (không tính hàng camera). */
    private fun build(c: IslandContent): Int {
        body.removeAllViews()
        val gray = Color.parseColor("#9A9A9A")
        val lightGray = Color.parseColor("#B8B8B8")

        // Hàng đầu: nằm ngang với lỗ camera, tên app đứng bên phải camera.
        val header = LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(holeD + dp(10f), 0, dp(14f), 0)
            addView(tv(c.label, 11f, gray))
        }
        body.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, holeD))

        val row = LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14f), 0, dp(14f), 0)
        }
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }

        if (c.kind == Kind.BATTERY) {
            row.addView(
                tv("⚡", 26f, Color.parseColor("#34C759")),
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(10f) }
            )
            col.addView(tv("${c.title}  ${c.percent}%", 15f, Color.WHITE, bold = true))
            val bar = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = c.percent
                progressTintList = ColorStateList.valueOf(
                    if (c.percent <= 20) Color.parseColor("#FF453A") else Color.parseColor("#34C759")
                )
            }
            col.addView(
                bar,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8f)).apply {
                    topMargin = dp(8f)
                }
            )
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            body.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46f)))
            return dp(46f)
        }

        val icon = ImageView(context).apply {
            setImageDrawable(c.icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(8f).toFloat())
                }
            }
            clipToOutline = true
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(40f), dp(40f)).apply { marginEnd = dp(10f) })

        col.addView(tv(c.title, 14f, Color.WHITE, bold = true))
        if (c.text.isNotBlank()) col.addView(tv(c.text, 13f, lightGray, lines = 2))
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        body.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58f)))

        if (c.kind == Kind.MUSIC) {
            val mc = c.controller
            val ctl = LinearLayout(context).apply { gravity = Gravity.CENTER }

            fun btn(res: Int, action: (ImageButton) -> Unit) = ImageButton(context).apply {
                setImageResource(res)
                setColorFilter(Color.WHITE)
                background = null
                setOnClickListener { action(this) }
            }

            ctl.addView(
                btn(android.R.drawable.ic_media_previous) { mc?.transportControls?.skipToPrevious() },
                LinearLayout.LayoutParams(dp(56f), dp(40f))
            )
            val playing = mc?.playbackState?.state == PlaybackState.STATE_PLAYING
            ctl.addView(
                btn(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play) { b ->
                    if (mc?.playbackState?.state == PlaybackState.STATE_PLAYING) {
                        mc?.transportControls?.pause()
                        b.setImageResource(android.R.drawable.ic_media_play)
                    } else {
                        mc?.transportControls?.play()
                        b.setImageResource(android.R.drawable.ic_media_pause)
                    }
                },
                LinearLayout.LayoutParams(dp(56f), dp(40f))
            )
            ctl.addView(
                btn(android.R.drawable.ic_media_next) { mc?.transportControls?.skipToNext() },
                LinearLayout.LayoutParams(dp(56f), dp(40f))
            )
            body.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44f)))
            return dp(58f) + dp(44f)
        }
        return dp(58f) + dp(6f)
    }
}
