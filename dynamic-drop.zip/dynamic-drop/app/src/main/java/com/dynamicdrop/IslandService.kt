package com.dynamicdrop

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager

class IslandService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var view: IslandView? = null
    private val hideTask = Runnable { view?.dismiss { view = null } }

    private var msm: MediaSessionManager? = null
    private var mediaStarted = false
    private val tracked = HashMap<MediaSession.Token, Pair<MediaController, MediaController.Callback>>()
    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> hook(list) }

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val pct = batteryPercent()
            when (intent.action) {
                Intent.ACTION_POWER_CONNECTED ->
                    show(IslandContent(Kind.BATTERY, "Pin", "Đang sạc", percent = pct, durationMs = 3500))
                Intent.ACTION_BATTERY_LOW ->
                    show(IslandContent(Kind.BATTERY, "Pin", "Pin yếu", percent = pct, durationMs = 4000))
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        IslandBus.service = this
        startForeground(1, buildNotification())
        registerReceiver(powerReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_BATTERY_LOW)
        })
        startMedia()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        IslandBus.service = null
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(powerReceiver)
        } catch (_: Exception) {
        }
        try {
            msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {
        }
        tracked.values.forEach { (c, cb) -> c.unregisterCallback(cb) }
        tracked.clear()
        view?.destroy()
        view = null
        super.onDestroy()
    }

    // ---------- hiển thị ----------

    fun show(c: IslandContent) {
        handler.post {
            if (!Settings.canDrawOverlays(this)) return@post
            val v = view ?: IslandView(this, wm) { content ->
                try {
                    content.intent?.send()
                } catch (_: Exception) {
                }
                handler.removeCallbacks(hideTask)
                handler.post(hideTask)
            }.also { view = it }
            v.present(c)
            handler.removeCallbacks(hideTask)
            handler.postDelayed(hideTask, c.durationMs)
        }
    }

    /** Huỷ view cũ để lần show sau đọc lại vị trí camera mới. */
    fun reset() {
        handler.post {
            handler.removeCallbacks(hideTask)
            view?.destroy()
            view = null
        }
    }

    // ---------- pin ----------

    private fun batteryPercent(): Int {
        val b = applicationContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return 0
        val level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (scale > 0) level * 100 / scale else 0
    }

    // ---------- nhạc ----------

    /** Gọi lại được nhiều lần; chỉ chạy được khi đã cấp quyền đọc thông báo. */
    fun startMedia() {
        if (mediaStarted) return
        val comp = ComponentName(this, NotifListener::class.java)
        try {
            val m = getSystemService(MediaSessionManager::class.java)
            m.addOnActiveSessionsChangedListener(sessionsListener, comp, handler)
            msm = m
            mediaStarted = true
            hook(m.getActiveSessions(comp))
        } catch (_: SecurityException) {
            // Chưa cấp quyền đọc thông báo, bỏ qua.
        }
    }

    private fun isPlaying(c: MediaController) = c.playbackState?.state == PlaybackState.STATE_PLAYING

    private fun hook(list: List<MediaController>?) {
        val live = list.orEmpty()
        val tokens = live.map { it.sessionToken }.toSet()
        tracked.keys.filter { it !in tokens }.forEach { t ->
            tracked.remove(t)?.let { (old, cb) -> old.unregisterCallback(cb) }
        }
        for (c in live) {
            if (tracked.containsKey(c.sessionToken)) continue
            val cb = object : MediaController.Callback() {
                var lastTitle: String? = c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                var wasPlaying = isPlaying(c)

                override fun onMetadataChanged(metadata: MediaMetadata?) {
                    val t = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                    if (t != null && t != lastTitle) {
                        lastTitle = t
                        if (isPlaying(c)) showMusic(c)
                    }
                }

                override fun onPlaybackStateChanged(state: PlaybackState?) {
                    val p = state?.state == PlaybackState.STATE_PLAYING
                    if (p && !wasPlaying) showMusic(c)
                    wasPlaying = p
                }
            }
            c.registerCallback(cb, handler)
            tracked[c.sessionToken] = c to cb
        }
    }

    private fun showMusic(c: MediaController) {
        val m = c.metadata ?: return
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
        val pm = packageManager
        val icon: Drawable? = art?.let { BitmapDrawable(resources, it) }
            ?: try {
                pm.getApplicationIcon(c.packageName)
            } catch (_: Exception) {
                null
            }
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(c.packageName, 0)).toString()
        } catch (_: Exception) {
            "Nhạc"
        }
        show(
            IslandContent(
                Kind.MUSIC, label, title, artist, icon,
                intent = c.sessionActivity, controller = c, durationMs = 6000
            )
        )
    }

    // ---------- notification của chính service ----------

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Dynamic Drop", NotificationManager.IMPORTANCE_MIN)
        )
        return Notification.Builder(this, "island")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Dynamic Drop đang chạy")
            .setOngoing(true)
            .build()
    }
}
