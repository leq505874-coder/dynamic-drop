package com.dynamicdrop

import android.content.Context

/** Lưu vị trí lỗ camera (đơn vị dp) và trạng thái bật/tắt. */
object Config {
    const val CX = "cx"      // tâm lỗ camera, cách mép trái
    const val CY = "cy"      // tâm lỗ camera, cách mép trên
    const val SIZE = "size"  // đường kính lỗ camera

    private fun p(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun get(c: Context, key: String, def: Float) = p(c).getFloat(key, def)
    fun set(c: Context, key: String, v: Float) = p(c).edit().putFloat(key, v).apply()

    fun cx(c: Context) = get(c, CX, 26f)
    fun cy(c: Context) = get(c, CY, 20f)
    fun size(c: Context) = get(c, SIZE, 22f)

    fun enabled(c: Context) = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()
}
