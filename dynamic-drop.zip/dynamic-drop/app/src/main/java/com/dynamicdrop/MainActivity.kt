package com.dynamicdrop

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }

        fun label(text: String, sp: Float = 14f, bold: Boolean = false) = TextView(this).apply {
            this.text = text
            textSize = sp
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(4))
        }

        fun button(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text
            setAllCaps(false)
            setOnClickListener { onClick() }
        }

        root.addView(label("Dynamic Drop", 26f, true))
        root.addView(label("Đảo động giả bung xuống từ camera góc trên bên trái."))
        status = label("")
        root.addView(status)

        root.addView(button("1. Cho phép hiển thị trên ứng dụng khác") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("2. Cho phép đọc thông báo (thông báo + nhạc)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        toggle = button("3. Bật đảo") { toggleService() }
        root.addView(toggle)

        root.addView(label("Căn lại cho khớp lỗ camera", 16f, true))
        root.addView(label("Kéo cho viên thuốc đen che vừa khít lỗ camera (đơn vị dp)."))
        addSlider(root, "Cách mép trái", Config.CX, 0, 100, 26f)
        addSlider(root, "Cách mép trên", Config.CY, 0, 60, 20f)
        addSlider(root, "Kích thước lỗ", Config.SIZE, 10, 44, 22f)

        root.addView(button("Thử hiệu ứng") { preview() })

        setContentView(ScrollView(this).apply {
            addView(root, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun overlayOk() = Settings.canDrawOverlays(this)

    private fun listenerOk(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return s?.contains(packageName) == true
    }

    private fun refresh() {
        status.text = "Hiển thị trên app khác: ${if (overlayOk()) "✅" else "❌ chưa cấp"}\n" +
            "Đọc thông báo: ${if (listenerOk()) "✅" else "❌ chưa cấp"}\n" +
            "Đảo: ${if (Config.enabled(this)) "đang bật" else "đang tắt"}"
        toggle.text = if (Config.enabled(this)) "3. Tắt đảo" else "3. Bật đảo"
    }

    private fun toggleService() {
        if (Config.enabled(this)) {
            stopService(Intent(this, IslandService::class.java))
            Config.setEnabled(this, false)
        } else {
            if (!overlayOk()) {
                Toast.makeText(this, "Cấp quyền hiển thị trên app khác trước đã", Toast.LENGTH_LONG).show()
                return
            }
            startForegroundService(Intent(this, IslandService::class.java))
            Config.setEnabled(this, true)
        }
        refresh()
    }

    private fun preview() {
        val s = IslandBus.service
        if (s == null) {
            Toast.makeText(this, "Bật đảo trước đã", Toast.LENGTH_SHORT).show()
            return
        }
        s.reset()
        IslandBus.show(
            IslandContent(
                Kind.NOTIF, "Dynamic Drop", "Xin chào 👋",
                "Đảo động giả đang chạy trên Oppo A53",
                icon = packageManager.getApplicationIcon(packageName),
                durationMs = 3500
            )
        )
    }

    private fun addSlider(root: LinearLayout, name: String, key: String, min: Int, max: Int, def: Float) {
        val t = TextView(this)
        val bar = SeekBar(this).apply {
            this.max = max - min
            progress = (Config.get(this@MainActivity, key, def) - min).toInt().coerceIn(0, max - min)
        }
        fun upd() {
            t.text = "$name: ${bar.progress + min} dp"
        }
        upd()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                upd()
                Config.set(this@MainActivity, key, (p + min).toFloat())
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                preview()
            }
        })
        root.addView(t)
        root.addView(bar)
    }
}
